"""

Interfaz de usuario por consola

"""